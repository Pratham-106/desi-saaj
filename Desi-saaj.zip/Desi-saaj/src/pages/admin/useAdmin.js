import { useAdminContext } from "./AdminContext";

export const useAdmin = () => {
  return useAdminContext();
};
