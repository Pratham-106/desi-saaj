import "./../css/NotFoundPage.css";

export default function NotFoundPage() {
  return (
    <section className="notfound-container">
      <h1>404 - Page Not Found</h1>
    </section>
  );
}
